﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TAInstrumentsTest
{
    public partial class Form1 : Form
    {
        private List<String> listOfWords;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeData();
        }

        private void InitializeData()
        {
            listOfWords = new List<string>();

            // read all the words from file to list 
            StreamReader sw = File.OpenText("Words.txt");

            while (!sw.EndOfStream)
            {
                listOfWords.Add(sw.ReadLine());
            }

            sw.Close();
        }

        private void buttonFindWords_Click(object sender, EventArgs e)
        {
            textBoxWordFoundCount.Text = String.Empty;
            listBoxWordsFound.Items.Clear();

            List<String> words = GetWordsWithText(textBoxLettersEntered.Text.ToUpper());
            textBoxWordFoundCount.Text = words.Count.ToString();

            // populate list box
            foreach (String word in words)
            {
                listBoxWordsFound.Items.Add(word);
            }
        }

        // get all words that have these letters, dictionary words can't have less letters than user entered
        private List<String> GetWordsWithText(string enteredText)
        {
            List<String> wordsFound = new List<string>();

            Dictionary<char, LetterWithCount> lettersEntered = CreateLetterCountDictionary(enteredText);

            foreach (LetterWithCount letter in lettersEntered.Values)
            {
                foreach (string wordFromList in listOfWords)
                {
                    if (WordHasAllChars(wordFromList, lettersEntered))
                    {
                        wordsFound.Add(wordFromList);
                    }
                }
            }

            return wordsFound;
        }

        // return true if a word has all of the required characters, also if a character was entered more than once it should be there that many times in the list word
        public bool WordHasAllChars(String listWord, Dictionary<char, LetterWithCount> lettersEntered)
        {
            Dictionary<char, LetterWithCount> wordFromListWithCount = CreateLetterCountDictionary(listWord);
            bool good = true;

            foreach (LetterWithCount l in lettersEntered.Values)
            {
                if (!wordFromListWithCount.ContainsKey(l.Letter))
                {
                    good = false;
                    break;
                }
                else
                {
                    if (l.Count > wordFromListWithCount[l.Letter].Count)
                    {
                        good = false;
                        break;
                    }
                }
            }

            return good;
        }

        // convert a string into a list of individual letters and their count
        private Dictionary<char, LetterWithCount> CreateLetterCountDictionary(string enteredText)
        {
            Dictionary<char, LetterWithCount> letters = new Dictionary<char, LetterWithCount>();

            foreach (char c in enteredText.ToArray())
            {
                if (!letters.ContainsKey(c))
                {
                    letters.Add(c, new LetterWithCount(c, 1));
                }
                else
                {
                    letters[c].Count++;
                }
            }

            return letters;
        }
    }

    public class LetterWithCount
    {
        public LetterWithCount( char c, int count )
        {
            Letter = c;
            Count = count;
        }

        public char Letter { get; set; }
        public int Count { get; set; }
    }
}
